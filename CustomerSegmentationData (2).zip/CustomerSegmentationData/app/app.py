import streamlit as st
import pandas as pd
import joblib
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

st.set_page_config(
    page_title="Customer Segmentation Dashboard",
    layout="wide"
)

st.title("🧠 Customer Segmentation & Marketing ROI Dashboard")

# ---------------- LOAD DATA ----------------
rfm = pd.read_csv("data/processed/rfm_features.csv")
roi_df = pd.read_csv("data/processed/roi_results.csv")

kmeans = joblib.load("models/kmeans_model.pkl")
scaler = joblib.load("models/scaler.pkl")

features = [
    'Recency',
    'Frequency',
    'Monetary',
    'AvgOrderValue',
    'ProductDiversity'
]

# ---------------- SIDEBAR ----------------
st.sidebar.header("🔍 New Customer Segmentation")

recency = st.sidebar.number_input("Recency (days)", min_value=0)
frequency = st.sidebar.number_input("Frequency", min_value=0)
monetary = st.sidebar.number_input("Monetary Value", min_value=0.0)
aov = st.sidebar.number_input("Avg Order Value", min_value=0.0)
diversity = st.sidebar.number_input("Product Diversity", min_value=0)

if st.sidebar.button("Predict Segment"):
    X = pd.DataFrame([[recency, frequency, monetary, aov, diversity]], columns=features)
    X_scaled = scaler.transform(X)
    cluster = kmeans.predict(X_scaled)[0]
    segment = rfm.loc[rfm['KMeans_Cluster'] == cluster, 'Segment'].iloc[0]
    st.sidebar.success(f"Predicted Segment: **{segment}**")

# ---------------- FILTER ----------------
st.sidebar.header("🎯 Filter Existing Customers")
selected_segment = st.sidebar.multiselect(
    "Select Segment(s)",
    rfm['Segment'].unique(),
    default=rfm['Segment'].unique()
)

filtered_rfm = rfm[rfm['Segment'].isin(selected_segment)]

# ---------------- PCA VISUALIZATION ----------------
st.subheader("📊 Customer Segments Visualization")

X_scaled_all = scaler.transform(filtered_rfm[features])
pca = PCA(n_components=2)
pca_data = pca.fit_transform(X_scaled_all)

filtered_rfm['PCA1'] = pca_data[:, 0]
filtered_rfm['PCA2'] = pca_data[:, 1]

fig, ax = plt.subplots(figsize=(8, 5))
sns.scatterplot(
    x='PCA1',
    y='PCA2',
    hue='Segment',
    data=filtered_rfm,
    ax=ax
)
plt.title("Customer Segmentation (PCA)")
st.pyplot(fig)

# ---------------- SEGMENT SUMMARY ----------------
st.subheader("📌 Segment Summary")
summary = filtered_rfm.groupby('Segment')[features].mean().round(2)
st.dataframe(summary)

# ---------------- ROI ----------------
st.subheader("💰 Marketing ROI by Segment")
st.dataframe(roi_df)

fig2, ax2 = plt.subplots(figsize=(6, 4))
sns.barplot(x="Segment", y="ROI", data=roi_df, ax=ax2)
ax2.axhline(0, linestyle='--')
plt.title("ROI Comparison")
st.pyplot(fig2)

# ---------------- DOWNLOAD ----------------
st.subheader("⬇️ Download Data")
st.download_button(
    "Download Segmented Customers",
    data=filtered_rfm.to_csv(index=False),
    file_name="segmented_customers.csv",
    mime="text/csv"
)
